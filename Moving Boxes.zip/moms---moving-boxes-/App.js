import React, { useState } from 'react';
import { StyleSheet, View, Text, PanResponder } from 'react-native';

export default function App() {
  const [box1Position, setBox1Position] = useState({ x: 50, y: 50 });
  const [box2Position, setBox2Position] = useState({ x: 200, y: 200 });

  const handlePanResponderMove = (e, boxPosition, setBoxPosition) => {
    const { pageX, pageY } = e.nativeEvent;
    setBoxPosition({ x: pageX - 50, y: pageY - 50 }); 
  };

  const panResponder1 = PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onPanResponderMove: (e) => handlePanResponderMove(e, box1Position, setBox1Position),
  });

  const panResponder2 = PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onPanResponderMove: (e) => handlePanResponderMove(e, box2Position, setBox2Position),
  });

  return (
    <View style={styles.container}>
      <View
        style={[styles.box, { left: box1Position.x, top: box1Position.y }]}
        {...panResponder1.panHandlers}
      >
        <Text></Text>
      </View>
      <View
        style={[styles.box2, { left: box2Position.x, top: box2Position.y }]}
        {...panResponder2.panHandlers}
      >
        <Text></Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
  },
  box: {
    position: 'absolute',
    width: 100,
    height: 100,
    backgroundColor: '#E5B80B',
    justifyContent: 'center',
    alignItems: 'center',
  },
    box2: {
    position: 'absolute',
    width: 100,
    height: 100,
    backgroundColor: 'black',
    justifyContent: 'center',
    alignItems: 'center',
  }
});
